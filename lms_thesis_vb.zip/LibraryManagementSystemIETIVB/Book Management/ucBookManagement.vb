﻿Public Class ucBookManagement

    Private Sub ucBookManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
