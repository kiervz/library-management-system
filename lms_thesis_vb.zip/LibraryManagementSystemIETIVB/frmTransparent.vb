﻿Public Class frmTransparent

End Class